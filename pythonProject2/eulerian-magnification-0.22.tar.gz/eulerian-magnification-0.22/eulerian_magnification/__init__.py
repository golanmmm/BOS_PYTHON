from .base import eulerian_magnification, show_frequencies

__version__ = '0.22'
